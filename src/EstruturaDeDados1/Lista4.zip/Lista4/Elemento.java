package EstruturaDeDados1.Lista4;

/**
 * 
 * Representa a referencia para um noh na lista.
 * 
 * NAO ALTERE ESSA CLASSE!
 *
 */
public class Elemento {

	Aluno alu;
	Elemento proximo;
	
}
